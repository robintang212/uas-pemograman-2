<?php

$nama=$_POST['nama'];
$harga=$_POST['harga'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into detail(nama, harga) 
                        values ('$nama','$harga')");

if($simpan==true){

    header("location:tampil-detail.php?pesan=inputBerhasil");
} else{
    echo "Error";
}

?>