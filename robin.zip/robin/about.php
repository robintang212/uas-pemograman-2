<?php include "header.php"; ?>
<br>
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
              <div class="jumbotron">
                <center>
                <h1><b>iSpy CCTV</b></h1>
                </center>
                <p>iSpy CCTV adalah perusahan salah satu perusahan cctv terbesar di Indonesia yang di dirikan oleh <mark><b>Robintang Hamonangan</b></mark> pada tahun 2010.
                Sejak berdiri pada tahun 2010, perusahaan CCTV ini telah menjadi saksi dari berbagai naik turun dalam industri keamanan. Awalnya, 
                mereka mungkin menghadapi tantangan dalam membangun pangsa pasar dan membangun reputasi, tetapi dengan dedikasi dan komitmen terhadap kualitas, 
                mereka berhasil mengatasi setiap rintangan yang muncul di sepanjang jalan. Melalui inovasi teknologi dan fokus yang tidak pernah kendur 
                pada kebutuhan pelanggan, perusahaan ini berhasil membangun portofolio produk yang kuat dan memperluas jaringan layanan mereka. 
                Meskipun mengalami berbagai dinamika industri dan persaingan yang ketat, perusahaan CCTV ini telah mempertahankan posisinya sebagai 
                pemimpin yang diandalkan dalam menyediakan solusi keamanan yang canggih dan handal. Dengan pengalaman dan pengetahuan yang mereka 
                kumpulkan selama bertahun-tahun,mereka siap menghadapi setiap tantangan di masa depan dan terus berkomitmen untuk memberikan layanan terbaik kepada pelanggan mereka.</p>               
                </div>
                </div>
                </div>
                </div>
               
      <?php include "footer.php";?>